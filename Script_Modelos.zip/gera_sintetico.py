"""Gera um CSV no MESMO formato da base UCI, apenas para validar o script.
NAO substitui a base real: serve so para conferir que o codigo roda sem erro."""
import numpy as np, pandas as pd

rng = np.random.default_rng(42)
idx = pd.date_range("2024-01-01", periods=150*24*60, freq="min")   # 150 dias, 1 min

h = idx.hour + idx.minute/60
dow = idx.dayofweek
# perfil diario: vale de madrugada, pico manha e noite
base = 0.25 + 0.55*np.exp(-((h-8)**2)/6) + 0.95*np.exp(-((h-20)**2)/8)
base *= np.where(dow >= 5, 1.25, 1.0)                     # fim de semana consome mais
base *= 1 + 0.10*np.sin(2*np.pi*idx.dayofyear/365)        # leve sazonalidade anual
picos = (rng.random(len(idx)) < 0.004) * rng.uniform(1.5, 4.0, len(idx))  # chuveiro etc.
pot = np.clip(base + picos + rng.normal(0, 0.08, len(idx)), 0.05, None)   # kW

df = pd.DataFrame({
    "Date": idx.strftime("%d/%m/%Y"),
    "Time": idx.strftime("%H:%M:%S"),
    "Global_active_power": np.round(pot, 3),
    "Global_reactive_power": np.round(pot*rng.uniform(0.05, 0.15, len(idx)), 3),
    "Voltage": np.round(rng.normal(240, 2.5, len(idx)), 2),
    "Global_intensity": np.round(pot*1000/240, 1),
    "Sub_metering_1": 0, "Sub_metering_2": 0, "Sub_metering_3": 0,
})
falta = rng.random(len(df)) < 0.0125          # ~1,25% de faltantes, como na base real
df["Global_active_power"] = df["Global_active_power"].astype(object)
df.loc[falta, "Global_active_power"] = "?"
df.to_csv("household_power_consumption.txt", sep=";", index=False)
print("gerado:", len(df), "linhas")
