import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error

def carregar_serie(caminho_csv):
    """Le a base UCI e devolve a serie de energia horaria em Wh."""
    df = pd.read_csv(caminho_csv, sep=';', low_memory=False, na_values=['?'])
    df['ts'] = pd.to_datetime(df['Date'] + ' ' + df['Time'],
                              format='%d/%m/%Y %H:%M:%S')
    df = df.set_index('ts').sort_index()
    pot = pd.to_numeric(df['Global_active_power'], errors='coerce')  # kW
    pot = pot.interpolate(limit=60)          # lacunas de ate 60 min
    energia_min_wh = pot * 1000.0 / 60.0     # kW -> Wh por minuto
    return energia_min_wh.resample('1h').sum().dropna()

def construir_atributos(s):
    X = pd.DataFrame(index=s.index)
    for lag in [1, 2, 3, 24, 168]:
        X[f'lag_{lag}'] = s.shift(lag)
    for jan in [3, 24, 168]:
        X[f'media_{jan}'] = s.shift(1).rolling(jan).mean()
        X[f'desvio_{jan}'] = s.shift(1).rolling(jan).std()
    h  = X.index.hour
    dw = X.index.dayofweek
    X['hora_sen'] = np.sin(2 * np.pi * h / 24)
    X['hora_cos'] = np.cos(2 * np.pi * h / 24)
    X['dsem_sen'] = np.sin(2 * np.pi * dw / 7)
    X['dsem_cos'] = np.cos(2 * np.pi * dw / 7)
    X['fim_semana'] = (dw >= 5).astype(int)
    X['mes'] = X.index.month
    y = s.copy()
    valido = X.notna().all(axis=1)
    return X[valido], y[valido]

def particionar(X, y, p_treino=0.70, p_val=0.15):
    n = len(X)
    i1, i2 = int(n * p_treino), int(n * (p_treino + p_val))
    return (X.iloc[:i1], y.iloc[:i1], X.iloc[i1:i2], y.iloc[i1:i2],
            X.iloc[i2:],  y.iloc[i2:])

def metricas(y_true, y_pred):
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mask = y_true > 1e-6
    mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    return {'MAE': mae, 'RMSE': rmse, 'MAPE': mape}

def executar(caminho_csv):
    s = carregar_serie(caminho_csv)
    print(f"Serie horaria: {len(s)} horas ({len(s)/24:.0f} dias)")
    X, y = construir_atributos(s)
    Xtr, ytr, Xva, yva, Xte, yte = particionar(X, y)
    print(f"Treino {len(Xtr)} | Validacao {len(Xva)} | Teste {len(Xte)}\n")

    resultados = {}
    pred_base = Xte['lag_24'].values
    resultados['Persistencia sazonal'] = metricas(yte.values, pred_base)

    esc = StandardScaler().fit(Xtr)
    ridge = Ridge(alpha=1.0).fit(esc.transform(Xtr), ytr)
    resultados['Ridge'] = metricas(yte.values, ridge.predict(esc.transform(Xte)))

    rf = RandomForestRegressor(n_estimators=300, max_depth=18, min_samples_leaf=2,
                               n_jobs=-1, random_state=42).fit(Xtr, ytr)
    resultados['Random Forest'] = metricas(yte.values, rf.predict(Xte))

    tab = pd.DataFrame(resultados).T.round(3)
    base_mae = tab.loc['Persistencia sazonal', 'MAE']
    tab['Reducao MAE (%)'] = ((base_mae - tab['MAE']) / base_mae * 100).round(1)
    tab.loc['Persistencia sazonal', 'Reducao MAE (%)'] = np.nan
    print(tab.to_string())

    imp = pd.Series(rf.feature_importances_, index=X.columns)
    print('\nImportancia dos atributos (top 10):')
    print(imp.sort_values(ascending=False).head(10).round(4).to_string())
    return resultados, rf, imp

if __name__ == '__main__':
    executar('household_power_consumption.txt')
