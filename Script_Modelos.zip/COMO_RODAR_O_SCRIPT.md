# Como rodar o script de treinamento dos modelos

O script produz o **Quadro 16** do TCC — a comparação entre os três modelos de previsão. É a evidência da hipótese H3. Não depende de nenhum hardware.

## 1. Instalar as dependências

```
pip install pandas numpy scikit-learn matplotlib
```

## 2. Baixar a base de dados

Acesse o repositório da UCI e procure por **Individual Household Electric Power Consumption**:

https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption

Baixe o arquivo compactado e descompacte. O arquivo que interessa chama-se `household_power_consumption.txt` e tem cerca de 130 MB.

Coloque-o na mesma pasta do script.

## 3. Executar

```
python treinar_modelos.py
```

O treinamento do Random Forest sobre a base completa leva alguns minutos. Sobre a base inteira, de quatro anos, a série horária terá cerca de 34 mil horas.

## 4. O que fazer com a saída

A tabela impressa vai direto para o **Quadro 16** (seção 9.5), com as colunas MAE, RMSE, MAPE e redução percentual frente ao baseline.

A lista de importância dos atributos alimenta a **análise da seção 9.6**. Comente quais variáveis dominaram: se as defasagens de 24 e 168 horas aparecerem no topo, isso confirma empiricamente a sazonalidade diária e semanal descrita na revisão de literatura.

## 5. Gráficos a gerar depois

Com os modelos treinados, acrescente ao final do script para produzir as figuras da seção 9.5:

```python
import matplotlib.pyplot as plt

# curva observada versus prevista, uma semana do conjunto de teste
plt.figure(figsize=(12, 4))
plt.plot(yte.index[:168], yte.values[:168], label='Observado', linewidth=2)
plt.plot(yte.index[:168], rf.predict(Xte)[:168], label='Random Forest')
plt.plot(yte.index[:168], Xte['lag_24'].values[:168], label='Baseline', alpha=0.6)
plt.ylabel('Energia (Wh)'); plt.legend(); plt.tight_layout()
plt.savefig('previsto_vs_observado.png', dpi=300)

# importancia dos atributos
imp.sort_values().tail(12).plot(kind='barh', figsize=(7, 5))
plt.xlabel('Importância relativa'); plt.tight_layout()
plt.savefig('importancia_atributos.png', dpi=300)
```

## Observação sobre a validação do script

O código foi executado e validado em ambiente controlado, com dados sintéticos gerados no mesmo formato da base real, para confirmar que roda sem erros. **Os números do seu trabalho precisam sair da sua execução sobre a base real** — isso é exigência da declaração de uso de IA que consta do documento.

Durante essa validação foi corrigido um defeito: a forma de leitura das colunas de data havia sido escrita em uma sintaxe removida nas versões recentes do pandas. A versão corrigida é a que está no Apêndice B e neste arquivo.
